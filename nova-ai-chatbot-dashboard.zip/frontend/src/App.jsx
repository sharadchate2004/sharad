import { useEffect, useMemo, useRef, useState } from "react";
import {
  Activity, ArrowDown, ArrowUp, Bot, Check, ChevronDown, CircleHelp, Command,
  FileText, Gauge, Menu, MessageSquare, MoreHorizontal, PanelLeftClose,
  Plus, Search, Settings2, ShieldCheck, Sparkles, Trash2, X, Zap
} from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";
const starterPrompts = [
  { icon: "✦", title: "Write a project plan", desc: "Turn an idea into clear milestones" },
  { icon: "⌘", title: "Explain a complex topic", desc: "Get a simple, structured explanation" },
  { icon: "↗", title: "Debug my code", desc: "Find issues and suggest fixes" },
  { icon: "▤", title: "Summarize a document", desc: "Extract the key points quickly" },
];

function makeChat(title = "New conversation") {
  return { id: crypto.randomUUID(), title, updatedAt: Date.now(), messages: [] };
}
function readChats() {
  try { return JSON.parse(localStorage.getItem("nova_chats") || "[]"); } catch { return []; }
}

export default function App() {
  const [chats, setChats] = useState(() => readChats());
  const [activeId, setActiveId] = useState(() => readChats()[0]?.id || null);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState("");
  const bottomRef = useRef(null);
  const active = chats.find(c => c.id === activeId) || null;
  const messages = active?.messages || [];

  useEffect(() => { localStorage.setItem("nova_chats", JSON.stringify(chats)); }, [chats]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, busy]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  const grouped = useMemo(() => {
    const q = search.toLowerCase();
    return chats.filter(c => c.title.toLowerCase().includes(q)).sort((a,b) => b.updatedAt-a.updatedAt);
  }, [chats, search]);

  function newChat() {
    const chat = makeChat();
    setChats(prev => [chat, ...prev]);
    setActiveId(chat.id);
    setInput("");
    setMobileOpen(false);
  }
  function updateMessages(id, next) {
    setChats(prev => prev.map(c => c.id === id ? {
      ...c, messages: next, updatedAt: Date.now(),
      title: c.messages.length === 0 && next[0]?.role === "user"
        ? next[0].content.slice(0, 34) + (next[0].content.length > 34 ? "…" : "")
        : c.title
    } : c));
  }
  async function send(text = input) {
    const content = text.trim();
    if (!content || busy) return;
    let chat = active;
    if (!chat) {
      chat = makeChat(content.slice(0, 34));
      setChats(prev => [chat, ...prev]);
      setActiveId(chat.id);
    }
    const userMessage = { role: "user", content, id: crypto.randomUUID() };
    const next = [...chat.messages, userMessage];
    updateMessages(chat.id, next);
    setInput("");
    setBusy(true);
    try {
      const res = await fetch(`${API}/api/chat`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next.map(({role, content}) => ({role, content})) })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.detail || "Could not reach the AI service.");
      }
      const data = await res.json();
      updateMessages(chat.id, [...next, {
        role: "assistant", content: data.reply, mode: data.mode, id: crypto.randomUUID()
      }]);
      if (data.mode === "demo") setToast("Demo mode · Add an API key for live AI");
    } catch (e) {
      updateMessages(chat.id, [...next, {
        role: "assistant",
        content: `I couldn't connect to the backend. Make sure the Python API is running at ${API}. (${e.message})`,
        error: true, id: crypto.randomUUID()
      }]);
    } finally { setBusy(false); }
  }
  function removeChat(id, e) {
    e?.stopPropagation();
    const next = chats.filter(c => c.id !== id);
    setChats(next);
    if (activeId === id) setActiveId(next[0]?.id || null);
  }
  function copyMessage(text) {
    navigator.clipboard?.writeText(text);
    setToast("Copied to clipboard");
  }

  return (
    <div className="app-shell">
      {mobileOpen && <button className="mobile-scrim" onClick={() => setMobileOpen(false)} aria-label="Close menu" />}
      <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
        <div className="brand-row">
          <div className="brand-mark"><Sparkles size={19} /></div>
          <span className="brand-name">nova<span>ai</span></span>
          <button className="icon-btn collapse-btn" title="Close sidebar" onClick={() => setMobileOpen(false)}><PanelLeftClose size={17}/></button>
        </div>
        <button className="new-chat-btn" onClick={newChat}><Plus size={17}/> New chat <span className="shortcut">⌘ K</span></button>
        <div className="side-search"><Search size={15}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search conversations"/></div>
        <div className="side-label">WORKSPACE</div>
        <button className="nav-item active"><MessageSquare size={16}/> Chats <span className="nav-count">{chats.length}</span></button>
        <button className="nav-item" onClick={() => setToast("Explore tools is coming soon")}><Gauge size={16}/> Explore tools</button>
        <button className="nav-item" onClick={() => setToast("Prompt library is coming soon")}><FileText size={16}/> Prompt library</button>
        <div className="history-head"><span className="side-label">RECENT</span><MoreHorizontal size={16}/></div>
        <div className="chat-history">
          {grouped.length === 0 && <div className="empty-history">No conversations yet</div>}
          {grouped.map(c => <div key={c.id} className={`history-item ${activeId === c.id ? "selected" : ""}`} onClick={() => {setActiveId(c.id);setMobileOpen(false);}}>
            <MessageSquare size={14}/><span>{c.title}</span>
            <button title="Delete chat" onClick={e => removeChat(c.id,e)}><Trash2 size={13}/></button>
          </div>)}
        </div>
        <div className="sidebar-bottom">
          <div className="upgrade-card"><div className="upgrade-icon"><Zap size={16}/></div><div><b>Unlock more with Nova</b><small>Explore advanced AI tools</small></div><ChevronDown size={14}/></div>
          <button className="profile-row" onClick={() => setToast("Profile settings coming soon")}><div className="avatar">SC</div><div className="profile-copy"><b>Workspace</b><small>Free plan</small></div><Settings2 size={17}/></button>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="top-left">
            <button className="icon-btn mobile-menu" onClick={() => setMobileOpen(true)}><Menu size={19}/></button>
            <div className="breadcrumb">Workspace <span>/</span> <b>AI Assistant</b></div>
          </div>
          <div className="top-actions">
            <div className="model-pill"><span className="online-dot"/><Bot size={15}/> Nova Assistant <ChevronDown size={14}/></div>
            <button className="icon-btn help-btn" onClick={() => setToast("Nova AI · React + FastAPI starter")}><CircleHelp size={18}/></button>
            <div className="avatar top-avatar">SC</div>
          </div>
        </header>

        <section className="content">
          {messages.length === 0 ? (
            <div className="welcome-wrap">
              <div className="welcome-orb"><div className="orb-core"><Sparkles size={27}/></div><i/><i/><i/></div>
              <div className="eyebrow"><span className="eyebrow-line"/> YOUR AI WORKSPACE <span className="eyebrow-line"/></div>
              <h1>Good to see you.<br/><span>What can I help with?</span></h1>
              <p className="welcome-sub">Your ideas, questions, and ambitious projects — let's make<br className="desktop-break"/> something great together.</p>
              <div className="prompt-grid">
                {starterPrompts.map(p => <button key={p.title} className="prompt-card" onClick={() => send(p.title + ". " + p.desc + ".")}><span className="prompt-icon">{p.icon}</span><b>{p.title}</b><small>{p.desc}</small><ArrowUp size={15} className="prompt-arrow"/></button>)}
              </div>
              <div className="privacy-note"><ShieldCheck size={14}/> Your workspace is private and secure</div>
            </div>
          ) : (
            <div className="conversation">
              <div className="conversation-title"><span>CONVERSATION</span><button onClick={() => copyMessage(messages.map(m=>`${m.role}: ${m.content}`).join("\n\n"))}>Copy chat <FileText size={14}/></button></div>
              {messages.map((m) => <div className={`message-row ${m.role}`} key={m.id}>
                <div className={`message-avatar ${m.role}`}>{m.role === "user" ? "SC" : <Sparkles size={16}/>}</div>
                <div className="message-body"><div className="message-meta">{m.role === "user" ? "You" : "Nova AI"} {m.mode === "demo" && <span className="demo-tag">DEMO MODE</span>} {m.error && <span className="error-tag">CONNECTION ISSUE</span>}</div>
                  <div className="message-text">{m.content}</div>
                  {m.role === "assistant" && <button className="copy-btn" onClick={() => copyMessage(m.content)}><FileText size={13}/> Copy response</button>}
                </div>
              </div>)}
              {busy && <div className="message-row assistant"><div className="message-avatar assistant"><Sparkles size={16}/></div><div className="message-body"><div className="message-meta">Nova AI</div><div className="typing"><i/><i/><i/></div></div></div>}
              <div ref={bottomRef}/>
            </div>
          )}
        </section>

        <footer className="composer-wrap">
          <div className="composer">
            <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => {if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}}} placeholder="Message Nova AI..." rows={1}/>
            <div className="composer-bottom"><div className="composer-tools"><button onClick={() => setToast("Attachments are not enabled in this starter")}><Plus size={16}/><span>Attach</span></button><span className="composer-hint">AI can make mistakes. Verify important information.</span></div><button className="send-btn" disabled={!input.trim() || busy} onClick={() => send()}><ArrowUp size={18}/></button></div>
          </div>
          <div className="footer-caption"><span><span className="online-dot"/> API workspace</span><span>Powered by Nova AI</span></div>
        </footer>
      </main>
      {toast && <div className="toast"><Check size={15}/>{toast}</div>}
    </div>
  );
}
