import os
from typing import List, Literal
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()

app = FastAPI(title="Nova AI API", version="1.0.0")
origin = os.getenv("FRONTEND_ORIGIN", "http://localhost:5173")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin, "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Message(BaseModel):
    role: Literal["user", "assistant", "system"]
    content: str = Field(min_length=1, max_length=12000)

class ChatRequest(BaseModel):
    messages: List[Message] = Field(min_length=1, max_length=40)

class ChatResponse(BaseModel):
    reply: str
    mode: Literal["live", "demo"]

@app.get("/")
def root():
    return {"name": "Nova AI API", "status": "online"}

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.post("/api/chat", response_model=ChatResponse)
def chat(payload: ChatRequest):
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        last = next((m.content for m in reversed(payload.messages) if m.role == "user"), "")
        return ChatResponse(
            mode="demo",
            reply=(
                "This is a demo response because no model API key is configured. "
                f"You said: “{last[:500]}”. Add OPENAI_API_KEY to backend/.env to enable live AI."
            ),
        )

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        response = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[{"role": m.role, "content": m.content} for m in payload.messages],
            temperature=0.7,
        )
        reply = response.choices[0].message.content or "I couldn't generate a response."
        return ChatResponse(reply=reply, mode="live")
    except Exception as exc:
        # Keep provider details out of the public response.
        print(f"Model provider error: {type(exc).__name__}: {exc}")
        from fastapi import HTTPException
        raise HTTPException(status_code=502, detail="The AI provider request failed. Check backend logs and API configuration.")
