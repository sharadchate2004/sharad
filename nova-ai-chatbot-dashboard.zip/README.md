# Nova AI — Dark Premium Chatbot Dashboard

A responsive React + FastAPI chatbot starter with:
- Dark premium dashboard UI
- Sidebar with new chat and conversation history
- Chat interface with user/assistant message bubbles
- Streaming-style typing indicator
- Backend API with optional OpenAI-compatible model integration
- Local browser persistence for chat history
- Mobile responsive layout

## Requirements
- Node.js 18+
- Python 3.10+

## 1. Start the Python backend
```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and add your API key if you want live AI responses.
```bash
uvicorn main:app --reload --port 8000
```
Backend runs at http://localhost:8000. API docs: http://localhost:8000/docs

## 2. Start the React frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite (usually http://localhost:5173).

## Live AI setup
In `backend/.env`:
```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-4o-mini
```
The backend uses the OpenAI Python SDK. If no key is configured, it returns a clearly labeled demo response so the UI can be tested without a paid API.

## Notes
- Never put API keys in React/Vite environment variables or frontend code.
- Chat history is stored in the browser's localStorage in this starter.
- This is a development starter. Add authentication, rate limiting, database storage, logging, and deployment secrets before production use.
