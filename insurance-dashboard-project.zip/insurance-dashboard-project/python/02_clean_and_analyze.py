"""
Step 2 - Clean the raw data with pandas, run the analysis, save summary tables + charts.

Cleaning rules (documented in docs/data_dictionary.md):
  1. Remove exact duplicates, then duplicate policy_id (keep first)
  2. Trim whitespace / standardise text (policy_type, region, gender, channel)
  3. Parse mixed date formats (YYYY-MM-DD and DD/MM/YYYY)
  4. Premium: negative values are sign errors -> absolute value
  5. Age: missing or outside 18-100 -> median age of that policy type
  6. Region / channel missing -> "Unknown"
  7. Claim amount greater than sum insured -> flagged and capped at sum insured
  8. Feature engineering: age_group, policy_year, policy_month, has_claim, claim_paid, ratios
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from config import RAW_CSV, CLEAN_CSV, OUTPUT_DIR, IMAGES_DIR

# ------------------------------------------------------------------ LOAD
raw = pd.read_csv(RAW_CSV)
df = raw.copy()
log = {"raw_rows": len(raw)}

# ------------------------------------------------------------------ CLEAN
# 1. duplicates
df = df.drop_duplicates()
df = df.drop_duplicates(subset="policy_id", keep="first")
log["duplicates_removed"] = log["raw_rows"] - len(df)

# 2. text standardisation
for col in ["policy_type", "region", "gender", "channel", "claim_status"]:
    df[col] = df[col].astype("string").str.strip()
df["policy_type"] = df["policy_type"].str.title()
df["gender"] = df["gender"].str.upper().str[0].map({"M": "Male", "F": "Female"})
df["region"] = df["region"].str.title().fillna("Unknown")
df["channel"] = df["channel"].fillna("Unknown")

# 3. dates (mixed formats)
def parse_dates(s: pd.Series) -> pd.Series:
    iso = pd.to_datetime(s, format="%Y-%m-%d", errors="coerce")
    dmy = pd.to_datetime(s, format="%d/%m/%Y", errors="coerce")
    return iso.fillna(dmy)

df["policy_start_date"] = parse_dates(df["policy_start_date"])
df["claim_date"] = parse_dates(df["claim_date"])
log["bad_dates"] = int(df["policy_start_date"].isna().sum())
df = df.dropna(subset=["policy_start_date"])

# 4. premium sign errors
log["negative_premiums_fixed"] = int((df["premium"] < 0).sum())
df["premium"] = df["premium"].abs()

# 5. age
bad_age = df["age"].isna() | ~df["age"].between(18, 100)
log["ages_imputed"] = int(bad_age.sum())
df.loc[bad_age, "age"] = np.nan
df["age"] = df["age"].fillna(df.groupby("policy_type")["age"].transform("median")).round().astype(int)

# 7. claim outliers
over = df["claim_amount"] > df["sum_insured"]
df["claim_outlier_flag"] = over.astype(int)
log["claims_capped_at_sum_insured"] = int(over.sum())
df.loc[over, "claim_amount"] = df.loc[over, "sum_insured"]

# 8. feature engineering
df["age_group"] = pd.cut(df["age"], bins=[17, 25, 35, 45, 55, 65, 100],
                         labels=["18-25", "26-35", "36-45", "46-55", "56-65", "65+"]).astype(str)
df["policy_year"] = df["policy_start_date"].dt.year
df["policy_month"] = df["policy_start_date"].dt.to_period("M").dt.to_timestamp()
df["has_claim"] = df["claim_amount"].notna().astype(int)
df["claim_amount"] = df["claim_amount"].fillna(0)
df["claim_paid"] = np.where(df["claim_status"].isin(["Approved", "Settled"]), df["claim_amount"], 0)
df["claim_status"] = df["claim_status"].fillna("No Claim")
df["claim_to_sum_insured"] = (df["claim_amount"] / df["sum_insured"]).round(4)
df["days_to_claim"] = (df["claim_date"] - df["policy_start_date"]).dt.days.astype("Int64")

col_order = ["policy_id", "customer_id", "age", "age_group", "gender", "region", "policy_type",
             "channel", "policy_start_date", "policy_year", "policy_month", "sum_insured",
             "premium", "has_claim", "claim_date", "claim_status", "claim_amount", "claim_paid",
             "claim_to_sum_insured", "days_to_claim", "claim_outlier_flag"]
df = df[col_order].sort_values("policy_start_date").reset_index(drop=True)

df.to_csv(CLEAN_CSV, index=False, date_format="%Y-%m-%d")
log["clean_rows"] = len(df)
print("\n=== CLEANING LOG ===")
for k, v in log.items():
    print(f"{k:32s}{v:>8,}")
pd.Series(log, name="count").to_csv(OUTPUT_DIR / "cleaning_log.csv")

# ------------------------------------------------------------------ ANALYSIS
def summarise(by):
    g = df.groupby(by).agg(
        policies=("policy_id", "count"),
        premium=("premium", "sum"),
        sum_insured=("sum_insured", "sum"),
        claims=("has_claim", "sum"),
        claim_amount=("claim_amount", "sum"),
        claim_paid=("claim_paid", "sum"),
    ).reset_index()
    g["claim_frequency_%"] = (g["claims"] / g["policies"] * 100).round(2)
    g["loss_ratio_%"] = (g["claim_paid"] / g["premium"] * 100).round(2)
    g["avg_premium"] = (g["premium"] / g["policies"]).round(0)
    return g

kpi = pd.DataFrame({
    "metric": ["Total Policies", "Total Premium", "Total Sum Insured", "Total Claims",
               "Total Claim Amount", "Claims Paid", "Claim Frequency %", "Loss Ratio %",
               "Avg Premium", "Avg Claim Amount"],
    "value": [len(df), df["premium"].sum(), df["sum_insured"].sum(), df["has_claim"].sum(),
              df["claim_amount"].sum(), df["claim_paid"].sum(),
              round(df["has_claim"].mean() * 100, 2),
              round(df["claim_paid"].sum() / df["premium"].sum() * 100, 2),
              round(df["premium"].mean(), 0),
              round(df.loc[df["has_claim"] == 1, "claim_amount"].mean(), 0)],
})
kpi.to_csv(OUTPUT_DIR / "kpi_summary.csv", index=False)
print("\n=== KPIs ===")
print(kpi.to_string(index=False))

tables = {
    "by_policy_type": summarise("policy_type"),
    "by_region": summarise("region"),
    "by_channel": summarise("channel"),
    "by_age_group": summarise("age_group"),
    "by_year": summarise("policy_year"),
    "by_month": summarise("policy_month"),
}
for name, t in tables.items():
    t.to_csv(OUTPUT_DIR / f"summary_{name}.csv", index=False)

print("\n=== BY POLICY TYPE ===")
print(tables["by_policy_type"].to_string(index=False))

# ------------------------------------------------------------------ CHARTS
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.spines.top": False,
                     "axes.spines.right": False, "axes.grid": True, "grid.alpha": .25})
BLUE, ORANGE = "#1F4E79", "#E07B39"

fig, axes = plt.subplots(2, 2, figsize=(14, 9))
fig.suptitle("Insurance Data Analysis - Overview", fontsize=16, fontweight="bold")

t = tables["by_policy_type"].sort_values("premium", ascending=False)
axes[0, 0].bar(t["policy_type"], t["premium"] / 1e6, color=BLUE)
axes[0, 0].set(title="Premium by Policy Type (INR mn)")

t = tables["by_policy_type"].sort_values("loss_ratio_%", ascending=False)
axes[0, 1].bar(t["policy_type"], t["loss_ratio_%"], color=ORANGE)
axes[0, 1].set(title="Loss Ratio % by Policy Type")

m = tables["by_month"]
axes[1, 0].plot(m["policy_month"], m["premium"] / 1e6, color=BLUE, label="Premium")
axes[1, 0].plot(m["policy_month"], m["claim_paid"] / 1e6, color=ORANGE, label="Claims paid")
axes[1, 0].set(title="Monthly Premium vs Claims Paid (INR mn)")
axes[1, 0].legend()

a = tables["by_age_group"]
axes[1, 1].bar(a["age_group"], a["claim_frequency_%"], color=BLUE)
axes[1, 1].set(title="Claim Frequency % by Age Group")

plt.tight_layout()
plt.savefig(IMAGES_DIR / "overview_charts.png", dpi=130)
print(f"\nSaved clean data -> {CLEAN_CSV}\nSaved summaries -> {OUTPUT_DIR}\nSaved chart -> {IMAGES_DIR / 'overview_charts.png'}")
