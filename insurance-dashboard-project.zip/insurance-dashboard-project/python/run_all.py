"""Run the whole pipeline: generate -> clean/analyse -> Excel.  (SQL load is optional.)"""
import subprocess, sys
from pathlib import Path

here = Path(__file__).parent
steps = ["01_generate_data.py", "02_clean_and_analyze.py", "04_export_excel.py"]
if "--with-sql" in sys.argv:
    steps.insert(2, "03_load_to_sql.py")

for s in steps:
    print(f"\n>>> {s}")
    subprocess.run([sys.executable, str(here / s)], check=True, cwd=here)
print("\nPipeline finished. Open excel/Insurance_Analysis.xlsx")
