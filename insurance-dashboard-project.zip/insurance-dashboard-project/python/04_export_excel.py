"""
Step 4 - Build the Excel workbook (Insurance_Analysis.xlsx)

Sheets
  Dashboard    KPI cards + charts (all numbers are live formulas)
  Analysis     SUMIFS / COUNTIFS summary tables by type, region, channel, age group, year
  Data         Cleaned dataset (output of step 2)
  Cleaning_Log What the cleaning step fixed (values copied from output/cleaning_log.csv)
"""
import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from config import CLEAN_CSV, EXCEL_FILE, OUTPUT_DIR

df = pd.read_csv(CLEAN_CSV, parse_dates=["policy_start_date", "policy_month", "claim_date"])
N = len(df)
LAST = N + 1  # last data row on the Data sheet

FONT = "Arial"
NAVY, LIGHT, GREY = "1F4E79", "DDEBF7", "F2F2F2"
hdr_font = Font(name=FONT, bold=True, color="FFFFFF", size=10)
hdr_fill = PatternFill("solid", fgColor=NAVY)
base = Font(name=FONT, size=10)
bold = Font(name=FONT, size=10, bold=True)
thin = Side(style="thin", color="BFBFBF")
box = Border(left=thin, right=thin, top=thin, bottom=thin)

wb = Workbook()
ws_dash = wb.active
ws_dash.title = "Dashboard"
ws_an = wb.create_sheet("Analysis")
ws_data = wb.create_sheet("Data")
ws_log = wb.create_sheet("Cleaning_Log")

# ------------------------------------------------------------------ DATA SHEET
cols = list(df.columns)
ws_data.append(cols)
for row in df.itertuples(index=False):
    ws_data.append([None if pd.isna(v) else (v.to_pydatetime() if isinstance(v, pd.Timestamp) else v)
                    for v in row])
for c in ws_data[1]:
    c.font, c.fill = hdr_font, hdr_fill
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
date_cols = {"policy_start_date", "policy_month", "claim_date"}
money_cols = {"sum_insured", "premium", "claim_amount", "claim_paid"}
for i, name in enumerate(cols, start=1):
    L = get_column_letter(i)
    ws_data.column_dimensions[L].width = 16
    fmt = "yyyy-mm-dd" if name in date_cols else "#,##0" if name in money_cols else \
          "0.0%" if name == "claim_to_sum_insured" else None
    for r in range(2, LAST + 1):
        cell = ws_data.cell(row=r, column=i)
        cell.font = base
        if fmt:
            cell.number_format = fmt
ws_data.freeze_panes = "B2"
ws_data.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{LAST}"
ws_data.row_dimensions[1].height = 30

def rng(col_name):
    L = get_column_letter(cols.index(col_name) + 1)
    return f"Data!${L}$2:${L}${LAST}"

R = {c: rng(c) for c in cols}

# ------------------------------------------------------------------ ANALYSIS SHEET
ws_an["A1"] = "Insurance Portfolio - Summary Tables (INR)"
ws_an["A1"].font = Font(name=FONT, size=14, bold=True, color=NAVY)
ws_an["A2"] = "All figures are formulas (SUMIFS / COUNTIFS) over the Data sheet - they update if the data changes."
ws_an["A2"].font = Font(name=FONT, size=9, italic=True, color="7F7F7F")

headers = ["Policies", "Premium", "Sum Insured", "Claims", "Claims Paid",
           "Claim Frequency", "Loss Ratio", "Avg Premium"]
blocks = {}   # name -> (first_data_row, last_data_row)
row = 4

def build_block(title, dim_col, cats):
    global row
    ws_an.cell(row=row, column=1, value=title).font = Font(name=FONT, size=11, bold=True, color=NAVY)
    row += 1
    for j, h in enumerate([dim_col.replace("_", " ").title()] + headers, start=1):
        c = ws_an.cell(row=row, column=j, value=h)
        c.font, c.fill, c.border = hdr_font, hdr_fill, box
        c.alignment = Alignment(horizontal="center", wrap_text=True)
    row += 1
    first = row
    for cat in cats:
        r = row
        ws_an.cell(row=r, column=1, value=cat)
        key = f"$A{r}"
        ws_an.cell(row=r, column=2, value=f'=COUNTIFS({R[dim_col]},{key})')
        ws_an.cell(row=r, column=3, value=f'=SUMIFS({R["premium"]},{R[dim_col]},{key})')
        ws_an.cell(row=r, column=4, value=f'=SUMIFS({R["sum_insured"]},{R[dim_col]},{key})')
        ws_an.cell(row=r, column=5, value=f'=SUMIFS({R["has_claim"]},{R[dim_col]},{key})')
        ws_an.cell(row=r, column=6, value=f'=SUMIFS({R["claim_paid"]},{R[dim_col]},{key})')
        ws_an.cell(row=r, column=7, value=f'=IFERROR(E{r}/B{r},0)')
        ws_an.cell(row=r, column=8, value=f'=IFERROR(F{r}/C{r},0)')
        ws_an.cell(row=r, column=9, value=f'=IFERROR(C{r}/B{r},0)')
        row += 1
    last = row - 1
    # total row
    ws_an.cell(row=row, column=1, value="Total")
    for col in (2, 3, 4, 5, 6):
        L = get_column_letter(col)
        ws_an.cell(row=row, column=col, value=f"=SUM({L}{first}:{L}{last})")
    ws_an.cell(row=row, column=7, value=f"=IFERROR(E{row}/B{row},0)")
    ws_an.cell(row=row, column=8, value=f"=IFERROR(F{row}/C{row},0)")
    ws_an.cell(row=row, column=9, value=f"=IFERROR(C{row}/B{row},0)")
    for j in range(1, 10):
        for r in range(first, row + 1):
            c = ws_an.cell(row=r, column=j)
            c.border = box
            c.font = bold if r == row else base
            if r == row:
                c.fill = PatternFill("solid", fgColor=LIGHT)
            if j in (3, 4, 6, 9):
                c.number_format = "#,##0"
            elif j in (2, 5):
                c.number_format = "#,##0"
            elif j in (7, 8):
                c.number_format = "0.0%"
    blocks[title] = (first, last, row)
    row += 3

build_block("By Policy Type", "policy_type", sorted(df["policy_type"].unique()))
build_block("By Region", "region", sorted(df["region"].unique()))
build_block("By Channel", "channel", sorted(df["channel"].unique()))
build_block("By Age Group", "age_group", ["18-25", "26-35", "36-45", "46-55", "56-65", "65+"])
build_block("By Policy Year", "policy_year", sorted(int(y) for y in df["policy_year"].unique()))

ws_an.column_dimensions["A"].width = 18
for L in "BCDEFGHI":
    ws_an.column_dimensions[L].width = 16
ws_an.freeze_panes = "A4"

# ------------------------------------------------------------------ DASHBOARD
ws_dash.sheet_view.showGridLines = False
ws_dash.merge_cells("A1:L1")
ws_dash["A1"] = "INSURANCE DATA ANALYSIS DASHBOARD"
ws_dash["A1"].font = Font(name=FONT, size=18, bold=True, color="FFFFFF")
ws_dash["A1"].fill = hdr_fill
ws_dash["A1"].alignment = Alignment(horizontal="center", vertical="center")
ws_dash.row_dimensions[1].height = 36
ws_dash["A2"] = "Source: cleaned policy & claims data (Data sheet). Amounts in INR."
ws_dash["A2"].font = Font(name=FONT, size=9, italic=True, color="7F7F7F")

t_first, t_last, t_tot = blocks["By Policy Type"]
kpis = [
    ("Total Policies",   f"=Analysis!B{t_tot}",  "#,##0"),
    ("Total Premium",    f"=Analysis!C{t_tot}",  "#,##0"),
    ("Total Claims",     f"=Analysis!E{t_tot}",  "#,##0"),
    ("Claims Paid",      f"=Analysis!F{t_tot}",  "#,##0"),
    ("Claim Frequency",  f"=Analysis!G{t_tot}",  "0.0%"),
    ("Loss Ratio",       f"=Analysis!H{t_tot}",  "0.0%"),
]
for k, (label, formula, fmt) in enumerate(kpis):
    c0 = 1 + k * 2
    ws_dash.merge_cells(start_row=4, start_column=c0, end_row=4, end_column=c0 + 1)
    ws_dash.merge_cells(start_row=5, start_column=c0, end_row=5, end_column=c0 + 1)
    lab, val = ws_dash.cell(row=4, column=c0, value=label), ws_dash.cell(row=5, column=c0, value=formula)
    lab.font = Font(name=FONT, size=10, bold=True, color=NAVY)
    val.font = Font(name=FONT, size=16, bold=True, color="000000")
    val.number_format = fmt
    for rr in (4, 5):
        for cc in (c0, c0 + 1):
            ws_dash.cell(row=rr, column=cc).fill = PatternFill("solid", fgColor=LIGHT)
            ws_dash.cell(row=rr, column=cc).alignment = Alignment(horizontal="center", vertical="center")
ws_dash.row_dimensions[5].height = 30
for i in range(1, 13):
    ws_dash.column_dimensions[get_column_letter(i)].width = 13

def bar(title, block, val_col, anchor, y_title, pct=False, line=False):
    first, last, _ = blocks[block]
    ch = LineChart() if line else BarChart()
    ch.title, ch.height, ch.width = title, 7.5, 15
    ch.y_axis.title = y_title
    ch.y_axis.number_format = "0%" if pct else "#,##0"
    ch.add_data(Reference(ws_an, min_col=val_col, min_row=first - 1, max_row=last), titles_from_data=True)
    ch.set_categories(Reference(ws_an, min_col=1, min_row=first, max_row=last))
    ch.legend = None
    ch.x_axis.delete = False
    ch.y_axis.delete = False
    ws_dash.add_chart(ch, anchor)

bar("Premium by Policy Type", "By Policy Type", 3, "A7", "INR")
bar("Loss Ratio by Policy Type", "By Policy Type", 8, "G7", "Loss ratio", pct=True)
bar("Premium by Region", "By Region", 3, "A23", "INR")
bar("Claim Frequency by Age Group", "By Age Group", 7, "G23", "Claim frequency", pct=True)
bar("Premium by Policy Year", "By Policy Year", 3, "A39", "INR", line=True)
bar("Loss Ratio by Channel", "By Channel", 8, "G39", "Loss ratio", pct=True)

# ------------------------------------------------------------------ CLEANING LOG
log = pd.read_csv(OUTPUT_DIR / "cleaning_log.csv")
ws_log.append(["Step", "Count"])
for r_ in log.itertuples(index=False):
    ws_log.append([str(r_[0]).replace("_", " ").capitalize(), int(r_[1])])
for c in ws_log[1]:
    c.font, c.fill = hdr_font, hdr_fill
for rr in ws_log.iter_rows(min_row=2):
    for c in rr:
        c.font = base
        if c.column == 2:
            c.number_format = "#,##0"
ws_log.column_dimensions["A"].width = 36
ws_log.column_dimensions["B"].width = 12
n = ws_log.max_row + 2
ws_log.cell(row=n, column=1, value="Source: output/cleaning_log.csv written by python/02_clean_and_analyze.py").font = \
    Font(name=FONT, size=9, italic=True, color="7F7F7F")

wb.save(EXCEL_FILE)
print(f"Excel workbook saved -> {EXCEL_FILE}")
