"""
Step 1 - Generate a realistic (and deliberately messy) insurance dataset.

Replace data/raw/insurance_raw.csv with your own data if you have it - the
cleaning script only expects the columns created here.
"""
import numpy as np
import pandas as pd
from config import RAW_CSV, N_POLICIES, SEED

rng = np.random.default_rng(SEED)
n = N_POLICIES

policy_types = ["Health", "Motor", "Life", "Home", "Travel"]
type_p = [0.32, 0.30, 0.18, 0.12, 0.08]
regions = ["North", "South", "East", "West", "Central"]
region_p = [0.22, 0.26, 0.14, 0.28, 0.10]
channels = ["Agent", "Online", "Broker", "Bancassurance"]
channel_p = [0.40, 0.30, 0.15, 0.15]

df = pd.DataFrame({
    "policy_id": [f"POL{100000 + i}" for i in range(n)],
    "customer_id": [f"CUST{rng.integers(1, int(n * 0.8)):05d}" for _ in range(n)],
    "age": rng.integers(18, 81, n).astype(float),
    "gender": rng.choice(["Male", "Female"], n, p=[0.52, 0.48]),
    "region": rng.choice(regions, n, p=region_p),
    "policy_type": rng.choice(policy_types, n, p=type_p),
    "channel": rng.choice(channels, n, p=channel_p),
})

# Policy start dates: Jan 2022 -> Sep 2026
start = pd.Timestamp("2022-01-01")
span_days = (pd.Timestamp("2026-09-30") - start).days
df["policy_start_date"] = start + pd.to_timedelta(rng.integers(0, span_days, n), unit="D")

# Sum insured & premium (INR)
si_range = {"Health": (300_000, 2_000_000), "Motor": (200_000, 1_500_000),
            "Life": (1_000_000, 10_000_000), "Home": (1_500_000, 8_000_000),
            "Travel": (50_000, 500_000)}
base_rate = {"Health": 0.030, "Motor": 0.035, "Life": 0.012, "Home": 0.004, "Travel": 0.025}

lo = df["policy_type"].map(lambda t: si_range[t][0]).to_numpy()
hi = df["policy_type"].map(lambda t: si_range[t][1]).to_numpy()
df["sum_insured"] = np.floor(rng.uniform(lo, hi) / 10_000) * 10_000
age_factor = 1 + (df["age"] - 18) / 100
df["premium"] = (df["sum_insured"] * df["policy_type"].map(base_rate) * age_factor
                 * rng.uniform(0.85, 1.15, n)).round(0)

# Claims
claim_prob = {"Health": 0.30, "Motor": 0.22, "Life": 0.04, "Home": 0.08, "Travel": 0.12}
p = df["policy_type"].map(claim_prob) * (1 + (df["age"] - 40) / 200)
has_claim = rng.random(n) < p.to_numpy()
sev = rng.lognormal(mean=-2.2, sigma=0.8, size=n)          # fraction of sum insured
df["claim_amount"] = np.where(has_claim, (df["sum_insured"] * np.clip(sev, 0.005, 1)).round(0), np.nan)
claim_offset = rng.integers(10, 360, n)
claim_dt = df["policy_start_date"] + pd.to_timedelta(claim_offset, unit="D")
df["claim_date"] = claim_dt.where(has_claim)
df["claim_status"] = pd.Series(
    rng.choice(["Approved", "Settled", "Rejected", "Pending"], n, p=[0.30, 0.40, 0.18, 0.12])
).where(has_claim)

# ---------- make it messy (so the cleaning step has real work) ----------
# mixed date formats stored as text
fmt_mask = rng.random(n) < 0.25
df["policy_start_date"] = df["policy_start_date"].dt.strftime("%Y-%m-%d")
df.loc[fmt_mask, "policy_start_date"] = pd.to_datetime(
    df.loc[fmt_mask, "policy_start_date"]).dt.strftime("%d/%m/%Y")
df["claim_date"] = df["claim_date"].dt.strftime("%Y-%m-%d")

# inconsistent labels / whitespace / case
def _mess_type(t):
    r = rng.random()
    return t.upper() if r < 0.05 else (t.lower() if r < 0.10 else t)
df["policy_type"] = df["policy_type"].map(_mess_type)
df["region"] = df["region"].map(lambda r: f" {r} " if rng.random() < 0.05 else r)
df["gender"] = df["gender"].map(lambda g: g[0] if rng.random() < 0.08 else g)

# missing values
df.loc[rng.random(n) < 0.03, "age"] = np.nan
df.loc[rng.random(n) < 0.02, "channel"] = None
df.loc[rng.random(n) < 0.01, "region"] = None

# invalid values & outliers
bad = rng.choice(n, 15, replace=False)
df.loc[bad, "premium"] = -df.loc[bad, "premium"]
df.loc[rng.choice(n, 10, replace=False), "age"] = 150
out_idx = rng.choice(np.where(has_claim)[0], 8, replace=False)
df.loc[out_idx, "claim_amount"] = df.loc[out_idx, "claim_amount"] * 20

# duplicate rows
df = pd.concat([df, df.sample(60, random_state=SEED)], ignore_index=True)
df = df.sample(frac=1, random_state=SEED).reset_index(drop=True)

df.to_csv(RAW_CSV, index=False)
print(f"Raw dataset created: {RAW_CSV}  ({len(df):,} rows, {df.shape[1]} columns)")
