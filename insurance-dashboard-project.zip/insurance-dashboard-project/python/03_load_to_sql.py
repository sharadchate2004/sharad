"""
Step 3 - Load the cleaned CSV into SQL Server (table dbo.insurance_policies).

Prerequisites
  * Run sql/01_create_database.sql and sql/02_create_tables.sql first
  * Install "ODBC Driver 17/18 for SQL Server"
  * Copy .env.example -> .env and edit the connection values
"""
import os
import urllib.parse
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text
from config import CLEAN_CSV, BASE_DIR

load_dotenv(BASE_DIR / ".env")
server = os.getenv("SQL_SERVER", r"localhost\SQLEXPRESS")
database = os.getenv("SQL_DATABASE", "InsuranceDB")
driver = os.getenv("SQL_DRIVER", "ODBC Driver 17 for SQL Server")
user, pwd = os.getenv("SQL_USER"), os.getenv("SQL_PASSWORD")

if user:
    conn_str = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};UID={user};PWD={pwd};TrustServerCertificate=yes"
else:
    conn_str = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};Trusted_Connection=yes;TrustServerCertificate=yes"

engine = create_engine(
    "mssql+pyodbc:///?odbc_connect=" + urllib.parse.quote_plus(conn_str),
    fast_executemany=True,
)

df = pd.read_csv(CLEAN_CSV, parse_dates=["policy_start_date", "policy_month", "claim_date"])
for c in ["policy_start_date", "policy_month", "claim_date"]:
    df[c] = df[c].dt.date                       # DATE columns
df = df.astype(object).where(df.notna(), None)  # NaN -> NULL

with engine.begin() as conn:
    conn.execute(text("TRUNCATE TABLE dbo.insurance_policies"))
    df.to_sql("insurance_policies", conn, schema="dbo", if_exists="append",
              index=False, chunksize=1000)
    n = conn.execute(text("SELECT COUNT(*) FROM dbo.insurance_policies")).scalar()

print(f"Loaded {n:,} rows into {database}.dbo.insurance_policies")
