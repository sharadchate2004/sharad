"""Shared paths and settings for the Insurance Data Analysis project."""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
RAW_CSV = BASE_DIR / "data" / "raw" / "insurance_raw.csv"
CLEAN_CSV = BASE_DIR / "data" / "processed" / "insurance_clean.csv"
OUTPUT_DIR = BASE_DIR / "output"
IMAGES_DIR = BASE_DIR / "docs" / "images"
EXCEL_FILE = BASE_DIR / "excel" / "Insurance_Analysis.xlsx"

N_POLICIES = 5000
SEED = 42

for _d in (OUTPUT_DIR, IMAGES_DIR, RAW_CSV.parent, CLEAN_CSV.parent, EXCEL_FILE.parent):
    _d.mkdir(parents=True, exist_ok=True)
