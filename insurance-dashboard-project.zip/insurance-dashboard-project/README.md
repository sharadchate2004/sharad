# 🛡️ Insurance Data Analysis Dashboard

An end-to-end data analytics project: raw insurance policy & claims data is **cleaned in Python**,
stored and queried in **SQL Server**, processed and summarised in **Excel**, and presented in an
interactive **Power BI** dashboard.

| Tool | Role in the project |
|---|---|
| 🐍 **Python** (pandas, matplotlib, SQLAlchemy) | Data generation, cleaning, feature engineering, analysis, loading |
| 🗄️ **SQL Server** (T-SQL) | Database, tables, indexes, reporting views, 12 business queries |
| 📗 **Excel** (openpyxl) | Formula-driven summary tables + KPI dashboard with charts |
| 📊 **Power BI** | Star-schema model, DAX measures, 3-page interactive dashboard |

## 🔄 Architecture

```
01_generate_data.py ─► raw CSV (messy, 5,060 rows)
02_clean_and_analyze.py ─► clean CSV (5,000 rows) + summary tables + charts
03_load_to_sql.py  ─► SQL Server  InsuranceDB.dbo.insurance_policies ─► views (vw_fact_*, vw_dim_*)
04_export_excel.py ─► Excel workbook (Dashboard / Analysis / Data / Cleaning_Log)
                                             Power BI ◄── SQL views  (or the clean CSV)
```

## 📁 Project structure

```
insurance-dashboard-project/
├── data/
│   ├── raw/insurance_raw.csv            # messy source data
│   └── processed/insurance_clean.csv    # cleaned output
├── python/
│   ├── config.py
│   ├── 01_generate_data.py
│   ├── 02_clean_and_analyze.py
│   ├── 03_load_to_sql.py
│   ├── 04_export_excel.py
│   └── run_all.py
├── sql/
│   ├── 01_create_database.sql
│   ├── 02_create_tables.sql
│   ├── 03_load_data.sql                 # BULK INSERT alternative to the Python loader
│   ├── 04_views.sql
│   └── 05_analysis_queries.sql
├── excel/Insurance_Analysis.xlsx
├── powerbi/
│   ├── README_PowerBI.md                # step-by-step build guide
│   ├── 01_power_query.m
│   ├── 02_dax_measures.dax
│   └── 03_theme.json
├── output/                              # summary CSVs + cleaning log
└── docs/ (data_dictionary.md, images/)
```

## 🚀 How to run

**1. Setup**
```bash
python -m venv .venv
.venv\Scripts\activate          # Windows   (Mac/Linux: source .venv/bin/activate)
pip install -r requirements.txt
```

**2. Python pipeline** (works without SQL Server)
```bash
cd python
python run_all.py
```

**3. SQL Server**
1. In SSMS run `sql/01_create_database.sql` then `sql/02_create_tables.sql`
2. Load data - choose one:
   - **Python:** copy `.env.example` to `.env`, edit the server name, then `python python/03_load_to_sql.py`
   - **T-SQL:** edit the file path in `sql/03_load_data.sql` and run it
3. Run `sql/04_views.sql`, then explore `sql/05_analysis_queries.sql`

**4. Excel** - open `excel/Insurance_Analysis.xlsx` (already built; regenerate with `04_export_excel.py`).

**5. Power BI** - follow `powerbi/README_PowerBI.md`.

## 🧹 Data cleaning performed
| Issue in raw data | Fix |
|---|---|
| 60 duplicate rows | Removed (exact + by `policy_id`) |
| Mixed date formats (`YYYY-MM-DD` & `DD/MM/YYYY`) | Parsed to a single date type |
| Inconsistent labels (`HEALTH`, `motor`, `" East "`, `M`/`F`) | Trimmed and standardised |
| 15 negative premiums | Treated as sign errors -> absolute value |
| 158 missing / impossible ages (e.g. 150) | Imputed with the policy-type median |
| Missing region / channel | Labelled `Unknown` |
| Claims larger than sum insured | Flagged (`claim_outlier_flag`) and capped |

## 📈 Sample findings (synthetic data, seed = 42)
- Portfolio of **5,000 policies**, ~**₹22.6 crore** premium, **19.5%** claim frequency, **64.3%** loss ratio.
- **Home** is loss-making (**158%** loss ratio) - few claims, but very large ones; **Health** is a watch item (**85%**).
- **Life** and **Travel** are the most profitable lines (~32% loss ratio).
- **Online** is the best-performing sales channel on loss ratio (57% vs 67-68% for Agent / Broker / Bancassurance).

> The data is synthetic, so treat these as demonstration results rather than real market insight.

## 💡 Skills demonstrated
Data cleaning & validation · feature engineering · SQL joins, CTEs, window functions (`LAG`, `RANK`,
running totals) · star-schema modeling · DAX & time intelligence · KPI design (loss ratio, claim frequency)
· dashboard storytelling.

## 📝 Resume bullets
- Built an end-to-end insurance analytics pipeline (Python -> SQL Server -> Excel -> Power BI) on 5,000 policies, cleaning 7 categories of data-quality issues.
- Wrote 12 T-SQL analyses (CTEs, window functions) to track loss ratio, claim frequency and YoY growth by product, region and channel.
- Designed a star-schema Power BI model with 20+ DAX measures and a 3-page interactive dashboard.

![Overview](docs/images/overview_charts.png)
