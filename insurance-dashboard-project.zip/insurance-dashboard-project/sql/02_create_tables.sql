/* =====================================================================
   02 - Create tables
   ===================================================================== */
USE InsuranceDB;
GO

IF OBJECT_ID('dbo.insurance_policies', 'U') IS NOT NULL DROP TABLE dbo.insurance_policies;
GO

CREATE TABLE dbo.insurance_policies (
    policy_id             VARCHAR(20)    NOT NULL PRIMARY KEY,
    customer_id           VARCHAR(20)    NOT NULL,
    age                   INT            NOT NULL,
    age_group             VARCHAR(10)    NOT NULL,
    gender                VARCHAR(10)    NULL,
    region                VARCHAR(20)    NOT NULL,
    policy_type           VARCHAR(20)    NOT NULL,
    channel               VARCHAR(20)    NOT NULL,
    policy_start_date     DATE           NOT NULL,
    policy_year           INT            NOT NULL,
    policy_month          DATE           NOT NULL,
    sum_insured           DECIMAL(15,2)  NOT NULL,
    premium               DECIMAL(15,2)  NOT NULL,
    has_claim             BIT            NOT NULL,
    claim_date            DATE           NULL,
    claim_status          VARCHAR(20)    NOT NULL,
    claim_amount          DECIMAL(15,2)  NOT NULL DEFAULT 0,
    claim_paid            DECIMAL(15,2)  NOT NULL DEFAULT 0,
    claim_to_sum_insured  DECIMAL(9,4)   NULL,
    days_to_claim         INT            NULL,
    claim_outlier_flag    BIT            NOT NULL DEFAULT 0
);
GO

CREATE INDEX IX_policies_type   ON dbo.insurance_policies (policy_type);
CREATE INDEX IX_policies_region ON dbo.insurance_policies (region);
CREATE INDEX IX_policies_month  ON dbo.insurance_policies (policy_month);
GO
