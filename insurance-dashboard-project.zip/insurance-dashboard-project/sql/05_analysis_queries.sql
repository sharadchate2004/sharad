/* =====================================================================
   05 - Business analysis queries
   Covers: aggregates, CASE, CTEs, window functions, subqueries, ranking
   ===================================================================== */
USE InsuranceDB;
GO

-- Q1. Headline KPIs ----------------------------------------------------
SELECT  COUNT(*)                                   AS total_policies,
        SUM(premium)                               AS total_premium,
        SUM(sum_insured)                           AS total_sum_insured,
        SUM(CAST(has_claim AS INT))                AS total_claims,
        SUM(claim_paid)                            AS claims_paid,
        CAST(100.0*SUM(CAST(has_claim AS INT))/COUNT(*) AS DECIMAL(6,2)) AS claim_frequency_pct,
        CAST(100.0*SUM(claim_paid)/SUM(premium)  AS DECIMAL(6,2))        AS loss_ratio_pct
FROM    dbo.insurance_policies;

-- Q2. Loss ratio by policy type (profitability) ------------------------
SELECT  policy_type, COUNT(*) AS policies, SUM(premium) AS premium, SUM(claim_paid) AS claims_paid,
        CAST(100.0*SUM(claim_paid)/SUM(premium) AS DECIMAL(8,2)) AS loss_ratio_pct,
        CASE WHEN 100.0*SUM(claim_paid)/SUM(premium) > 100 THEN 'Loss-making'
             WHEN 100.0*SUM(claim_paid)/SUM(premium) > 70  THEN 'Watch'
             ELSE 'Profitable' END AS health_flag
FROM    dbo.insurance_policies
GROUP BY policy_type
ORDER BY loss_ratio_pct DESC;

-- Q3. Claim frequency & severity by age group --------------------------
SELECT  age_group,
        COUNT(*)                                   AS policies,
        SUM(CAST(has_claim AS INT))                AS claims,
        CAST(100.0*SUM(CAST(has_claim AS INT))/COUNT(*) AS DECIMAL(6,2)) AS claim_frequency_pct,
        AVG(CASE WHEN has_claim = 1 THEN claim_amount END)               AS avg_claim_severity
FROM    dbo.insurance_policies
GROUP BY age_group
ORDER BY age_group;

-- Q4. Region x policy type premium matrix ------------------------------
SELECT  region,
        SUM(CASE WHEN policy_type='Health' THEN premium ELSE 0 END) AS health,
        SUM(CASE WHEN policy_type='Motor'  THEN premium ELSE 0 END) AS motor,
        SUM(CASE WHEN policy_type='Life'   THEN premium ELSE 0 END) AS life,
        SUM(CASE WHEN policy_type='Home'   THEN premium ELSE 0 END) AS home,
        SUM(CASE WHEN policy_type='Travel' THEN premium ELSE 0 END) AS travel,
        SUM(premium) AS total
FROM    dbo.insurance_policies
GROUP BY region
ORDER BY total DESC;

-- Q5. Monthly premium trend with running total & 3-month moving average
WITH monthly AS (
    SELECT policy_month, SUM(premium) AS premium, SUM(claim_paid) AS claims_paid
    FROM   dbo.insurance_policies
    GROUP BY policy_month
)
SELECT  policy_month, premium, claims_paid,
        SUM(premium) OVER (ORDER BY policy_month ROWS UNBOUNDED PRECEDING)       AS running_premium,
        AVG(premium) OVER (ORDER BY policy_month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS moving_avg_3m
FROM    monthly
ORDER BY policy_month;

-- Q6. Year-over-year premium growth by policy type ---------------------
WITH yearly AS (
    SELECT policy_type, policy_year, SUM(premium) AS premium
    FROM   dbo.insurance_policies
    GROUP BY policy_type, policy_year
)
SELECT  policy_type, policy_year, premium,
        LAG(premium) OVER (PARTITION BY policy_type ORDER BY policy_year) AS prev_year,
        CAST(100.0*(premium - LAG(premium) OVER (PARTITION BY policy_type ORDER BY policy_year))
             / NULLIF(LAG(premium) OVER (PARTITION BY policy_type ORDER BY policy_year),0) AS DECIMAL(8,2)) AS yoy_growth_pct
FROM    yearly
ORDER BY policy_type, policy_year;

-- Q7. Channel performance ranking --------------------------------------
SELECT  channel, COUNT(*) AS policies, SUM(premium) AS premium,
        CAST(100.0*SUM(claim_paid)/SUM(premium) AS DECIMAL(8,2)) AS loss_ratio_pct,
        RANK() OVER (ORDER BY SUM(premium) DESC)                  AS premium_rank,
        RANK() OVER (ORDER BY SUM(claim_paid)/SUM(premium) ASC)   AS profitability_rank
FROM    dbo.insurance_policies
GROUP BY channel;

-- Q8. Top 3 claims in every policy type (ROW_NUMBER) -------------------
WITH ranked AS (
    SELECT policy_id, policy_type, region, claim_amount, claim_status,
           ROW_NUMBER() OVER (PARTITION BY policy_type ORDER BY claim_amount DESC) AS rn
    FROM   dbo.insurance_policies
    WHERE  has_claim = 1
)
SELECT * FROM ranked WHERE rn <= 3 ORDER BY policy_type, rn;

-- Q9. Claim settlement mix --------------------------------------------
SELECT  claim_status, COUNT(*) AS claims, SUM(claim_amount) AS amount,
        CAST(100.0*COUNT(*)/SUM(COUNT(*)) OVER () AS DECIMAL(6,2)) AS pct_of_claims
FROM    dbo.insurance_policies
WHERE   has_claim = 1
GROUP BY claim_status;

-- Q10. Potential fraud / review list: claim >= 80% of sum insured or filed within 30 days
SELECT  policy_id, customer_id, policy_type, region, sum_insured, claim_amount,
        claim_to_sum_insured, days_to_claim, claim_status
FROM    dbo.insurance_policies
WHERE   has_claim = 1
  AND  (claim_to_sum_insured >= 0.80 OR days_to_claim <= 30)
ORDER BY claim_to_sum_insured DESC;

-- Q11. Customers with multiple policies (cross-sell base) -------------
SELECT  customer_id, COUNT(*) AS policies, SUM(premium) AS total_premium,
        STRING_AGG(policy_type, ', ') AS products
FROM    dbo.insurance_policies
GROUP BY customer_id
HAVING  COUNT(*) > 1
ORDER BY total_premium DESC;

-- Q12. Segments with above-average loss ratio (subquery) --------------
SELECT  region, policy_type,
        CAST(100.0*SUM(claim_paid)/SUM(premium) AS DECIMAL(8,2)) AS loss_ratio_pct
FROM    dbo.insurance_policies
GROUP BY region, policy_type
HAVING  SUM(claim_paid)/SUM(premium) >
        (SELECT SUM(claim_paid)/SUM(premium) FROM dbo.insurance_policies)
ORDER BY loss_ratio_pct DESC;
GO
