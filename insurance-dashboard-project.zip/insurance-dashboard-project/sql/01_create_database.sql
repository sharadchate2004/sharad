/* =====================================================================
   01 - Create database
   Run in SSMS (SQL Server Management Studio) or Azure Data Studio
   ===================================================================== */
IF DB_ID('InsuranceDB') IS NULL
    CREATE DATABASE InsuranceDB;
GO
USE InsuranceDB;
GO
