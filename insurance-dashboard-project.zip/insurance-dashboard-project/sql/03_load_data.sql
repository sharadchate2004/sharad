/* =====================================================================
   03 - Load data  (OPTION B - T-SQL).  OPTION A is python/03_load_to_sql.py
   1. Change the file path below to where insurance_clean.csv lives.
      (SQL Server service account needs read permission on that folder.)
   ===================================================================== */
USE InsuranceDB;
GO

TRUNCATE TABLE dbo.insurance_policies;
GO

BULK INSERT dbo.insurance_policies
FROM 'C:\InsuranceProject\data\processed\insurance_clean.csv'   -- <== CHANGE ME
WITH (
    FIRSTROW        = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    CODEPAGE        = '65001',
    TABLOCK
);
GO

SELECT COUNT(*) AS rows_loaded FROM dbo.insurance_policies;
GO
