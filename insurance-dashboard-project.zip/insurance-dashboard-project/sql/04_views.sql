/* =====================================================================
   04 - Reporting views (Power BI connects to these)
   Star-schema style: one fact view + small dimension views
   ===================================================================== */
USE InsuranceDB;
GO

CREATE OR ALTER VIEW dbo.vw_fact_policies AS
SELECT  policy_id, customer_id, age, age_group, gender, region, policy_type, channel,
        policy_start_date, policy_year, policy_month,
        sum_insured, premium, has_claim, claim_date, claim_status,
        claim_amount, claim_paid, claim_to_sum_insured, days_to_claim, claim_outlier_flag
FROM    dbo.insurance_policies;
GO

CREATE OR ALTER VIEW dbo.vw_dim_policy_type AS
SELECT DISTINCT policy_type FROM dbo.insurance_policies;
GO

CREATE OR ALTER VIEW dbo.vw_dim_region AS
SELECT DISTINCT region FROM dbo.insurance_policies;
GO

CREATE OR ALTER VIEW dbo.vw_dim_channel AS
SELECT DISTINCT channel FROM dbo.insurance_policies;
GO

CREATE OR ALTER VIEW dbo.vw_dim_age_group AS
SELECT age_group,
       CASE age_group WHEN '18-25' THEN 1 WHEN '26-35' THEN 2 WHEN '36-45' THEN 3
                      WHEN '46-55' THEN 4 WHEN '56-65' THEN 5 ELSE 6 END AS sort_order
FROM (SELECT DISTINCT age_group FROM dbo.insurance_policies) x;
GO

CREATE OR ALTER VIEW dbo.vw_kpi_by_policy_type AS
SELECT  policy_type,
        COUNT(*)                                             AS policies,
        SUM(premium)                                         AS total_premium,
        SUM(CAST(has_claim AS INT))                          AS total_claims,
        SUM(claim_paid)                                      AS claims_paid,
        CAST(100.0 * SUM(CAST(has_claim AS INT)) / COUNT(*) AS DECIMAL(6,2)) AS claim_frequency_pct,
        CAST(100.0 * SUM(claim_paid) / NULLIF(SUM(premium),0) AS DECIMAL(8,2)) AS loss_ratio_pct
FROM    dbo.insurance_policies
GROUP BY policy_type;
GO
