// =====================================================================
// POWER QUERY (M) - paste into Home > Get Data > Blank Query > Advanced Editor
// Create one query per block below and name them exactly as shown.
// =====================================================================

// ---------- Query: FactPolicies  (SQL Server) ----------
let
    Source   = Sql.Database("localhost\SQLEXPRESS", "InsuranceDB"),   // <== your server
    Policies = Source{[Schema = "dbo", Item = "vw_fact_policies"]}[Data],
    Typed    = Table.TransformColumnTypes(Policies, {
                 {"policy_start_date", type date}, {"policy_month", type date},
                 {"claim_date", type date}, {"sum_insured", Currency.Type},
                 {"premium", Currency.Type}, {"claim_amount", Currency.Type},
                 {"claim_paid", Currency.Type}, {"age", Int64.Type},
                 {"policy_year", Int64.Type}, {"has_claim", Int64.Type}})
in
    Typed

// ---------- Query: FactPolicies  (ALTERNATIVE - no SQL Server, read the CSV) ----------
// let
//     Source = Csv.Document(File.Contents("C:\InsuranceProject\data\processed\insurance_clean.csv"),
//                [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
//     Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
//     Typed = Table.TransformColumnTypes(Promoted, {
//                 {"policy_start_date", type date}, {"policy_month", type date}, {"claim_date", type date},
//                 {"sum_insured", Currency.Type}, {"premium", Currency.Type}, {"claim_amount", Currency.Type},
//                 {"claim_paid", Currency.Type}, {"age", Int64.Type}, {"policy_year", Int64.Type},
//                 {"has_claim", Int64.Type}}, "en-US")
// in Typed

// ---------- Queries: DimPolicyType / DimRegion / DimChannel / DimAgeGroup ----------
// Same pattern - only the Item name changes:
let
    Source = Sql.Database("localhost\SQLEXPRESS", "InsuranceDB"),
    DimPolicyType = Source{[Schema = "dbo", Item = "vw_dim_policy_type"]}[Data]
in
    DimPolicyType
//   vw_dim_region   -> DimRegion
//   vw_dim_channel  -> DimChannel
//   vw_dim_age_group -> DimAgeGroup   (then sort age_group by sort_order in the model)
