# Power BI Dashboard - Build Guide

> A `.pbix` file can only be created inside Power BI Desktop, so this folder gives you
> everything needed to build it in about 20 minutes: queries, model, DAX, theme and a page layout.

## 1. Connect to data
1. Open **Power BI Desktop > Get data > Blank query > Advanced editor**.
2. Paste the queries from `01_power_query.m` (one query per block):
   `FactPolicies`, `DimPolicyType`, `DimRegion`, `DimChannel`, `DimAgeGroup`.
3. No SQL Server? Use the commented **CSV alternative** in the same file.
4. **Close & Apply.**

## 2. Build the model (Model view)
Create `DimDate` and the measures from `02_dax_measures.dax`, then add these relationships
(all **many-to-one, single direction**, dimension -> fact):

| From (dimension)            | To (FactPolicies)         |
|-----------------------------|---------------------------|
| DimDate[Date]               | policy_start_date         |
| DimPolicyType[policy_type]  | policy_type               |
| DimRegion[region]           | region                    |
| DimChannel[channel]         | channel                   |
| DimAgeGroup[age_group]      | age_group                 |

Sort `DimAgeGroup[age_group]` by `sort_order`. Hide the key columns on the fact table.

## 3. Apply the theme
**View > Themes > Browse for themes** -> `03_theme.json`.

## 4. Report pages

### Page 1 - Executive Overview
| Visual | Fields |
|---|---|
| 6 KPI **cards** | Total Policies, Total Premium, Total Claims, Claims Paid, Claim Frequency %, Loss Ratio % |
| **Line + clustered column** | X = DimDate[Year-Month]; columns = Total Premium; line = Claims Paid |
| **Clustered bar** | Axis = policy_type; Values = Total Premium |
| **Donut** | Legend = claim_status (filter has_claim = 1); Values = Total Claims |
| **Slicers** | Year, Region, Channel |

### Page 2 - Claims & Risk
| Visual | Fields |
|---|---|
| **Column** | Axis = age_group; Values = Claim Frequency % |
| **Matrix** | Rows = policy_type; Columns = region; Values = Loss Ratio % (conditional-format bg using `Loss Ratio Color`) |
| **Scatter** | X = Avg Premium; Y = Loss Ratio %; Size = Total Policies; Details = policy_type |
| **Table** (drill-through) | policy_id, policy_type, claim_amount, claim_to_sum_insured, days_to_claim, claim_status; filter `High-Risk Claims` |

### Page 3 - Growth & Channels
| Visual | Fields |
|---|---|
| **Clustered column** | Axis = Year; Values = Total Premium, Premium LY |
| **KPI visual** | Value = Premium YTD; Trend = DimDate[Month] |
| **Treemap** | Group = channel; Values = Total Premium |
| **Filled map** | Location = region (optional) |

## 5. Polish checklist
- [ ] Add a title bar and your name / LinkedIn link on every page
- [ ] Add **bookmarks + page navigator** buttons
- [ ] Turn on **Sync slicers** across pages
- [ ] Add alt-text to every visual (accessibility)
- [ ] Export 3 screenshots into `docs/images/` for your portfolio / GitHub README
- [ ] Save as `powerbi/Insurance_Dashboard.pbix`
