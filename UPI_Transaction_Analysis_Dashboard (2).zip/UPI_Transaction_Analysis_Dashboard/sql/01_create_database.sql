CREATE DATABASE IF NOT EXISTS upi_analysis;
USE upi_analysis;

CREATE TABLE IF NOT EXISTS upi_transactions (
    Transaction_ID VARCHAR(20) PRIMARY KEY,
    Transaction_Date DATE NOT NULL,
    Transaction_Time TIME,
    Customer_ID VARCHAR(20),
    Sender_Bank VARCHAR(50),
    Receiver_Bank VARCHAR(50),
    UPI_App VARCHAR(50),
    Merchant_Category VARCHAR(100),
    City VARCHAR(100),
    Transaction_Amount DECIMAL(12,2),
    Transaction_Status VARCHAR(20),
    Payment_Mode VARCHAR(20)
);
