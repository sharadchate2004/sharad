USE upi_analysis;

-- 1. Overall KPI
SELECT COUNT(*) AS total_transactions,
       SUM(Transaction_Status='Success') AS successful_transactions,
       ROUND(100*SUM(Transaction_Status='Success')/COUNT(*),2) AS success_rate_pct,
       ROUND(SUM(Transaction_Amount),2) AS total_transaction_value,
       ROUND(AVG(Transaction_Amount),2) AS average_transaction_amount,
       COUNT(DISTINCT Customer_ID) AS unique_customers
FROM upi_transactions;

-- 2. Monthly transaction trend
SELECT DATE_FORMAT(Transaction_Date,'%Y-%m') AS month,
       COUNT(*) AS transactions,
       ROUND(SUM(Transaction_Amount),2) AS transaction_value,
       SUM(Transaction_Status='Success') AS successful
FROM upi_transactions
GROUP BY month ORDER BY month;

-- 3. UPI app performance
SELECT UPI_App, COUNT(*) AS transactions,
       ROUND(SUM(Transaction_Amount),2) AS total_value,
       ROUND(100*AVG(Transaction_Status='Success'),2) AS success_rate_pct
FROM upi_transactions GROUP BY UPI_App ORDER BY total_value DESC;

-- 4. City-wise performance
SELECT City, COUNT(*) AS transactions,
       ROUND(SUM(Transaction_Amount),2) AS total_value,
       ROUND(100*AVG(Transaction_Status='Success'),2) AS success_rate_pct
FROM upi_transactions GROUP BY City ORDER BY total_value DESC;

-- 5. Merchant category
SELECT Merchant_Category, COUNT(*) AS transactions,
       ROUND(SUM(Transaction_Amount),2) AS total_value
FROM upi_transactions GROUP BY Merchant_Category ORDER BY total_value DESC;

-- 6. Failure analysis
SELECT UPI_App, COUNT(*) AS failed_transactions
FROM upi_transactions WHERE Transaction_Status='Failed'
GROUP BY UPI_App ORDER BY failed_transactions DESC;

-- 7. Peak transaction hours
SELECT HOUR(Transaction_Time) AS transaction_hour, COUNT(*) AS transactions
FROM upi_transactions GROUP BY transaction_hour ORDER BY transactions DESC;

-- 8. Top 10 customers by successful transaction value
SELECT Customer_ID, ROUND(SUM(Transaction_Amount),2) AS successful_value,
       COUNT(*) AS successful_transactions
FROM upi_transactions WHERE Transaction_Status='Success'
GROUP BY Customer_ID ORDER BY successful_value DESC LIMIT 10;
