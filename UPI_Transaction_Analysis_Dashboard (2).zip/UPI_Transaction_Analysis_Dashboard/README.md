# UPI Transaction Analysis Dashboard

A beginner-friendly portfolio project using **Python, Excel, MySQL, Power BI, DAX and Data Analysis**.

> Dataset is synthetic/sample data generated for learning and portfolio demonstration. It is not real bank or customer transaction data.

## Project structure
- `data/upi_transactions.csv` — source dataset (2,000 sample records)
- `data/upi_transactions.xlsx` — same dataset in Excel format
- `python/analysis.py` — pandas analysis and exportable summaries
- `sql/01_create_database.sql` — MySQL database/table
- `sql/03_analysis_queries.sql` — KPI and analysis queries
- `powerbi/DAX_Measures.txt` — DAX measures and Calendar table
- `docs/POWER_BI_BUILD_GUIDE.md` — report setup and visual layout

## Run Python analysis
```bash
pip install -r requirements.txt
python python/analysis.py
```
Output CSV summaries are created under `data/analysis_outputs/`.

## MySQL setup
1. Open MySQL Workbench and connect to your local server.
2. Run `sql/01_create_database.sql`.
3. Import `data/upi_transactions.csv` into `upi_analysis.upi_transactions` using Table Data Import Wizard.
4. Run queries in `sql/03_analysis_queries.sql`.

## Power BI
Follow `docs/POWER_BI_BUILD_GUIDE.md`. Import the Excel file, create Calendar table and measures, then build the suggested report.

## Portfolio note
Mention clearly that this is a sample-data project. Replace synthetic data with an authorized, anonymized dataset before making real-world claims.
