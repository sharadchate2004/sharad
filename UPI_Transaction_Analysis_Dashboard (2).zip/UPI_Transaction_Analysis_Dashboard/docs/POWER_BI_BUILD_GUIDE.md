# Power BI Dashboard Build Guide

## 1. Import
1. Open Power BI Desktop.
2. Get Data > Excel or Text/CSV.
3. Select `data/upi_transactions.xlsx` (or CSV) and load `Transactions`.
4. Set `Transaction_Date` to Date, `Transaction_Time` to Time, and `Transaction_Amount` to Decimal Number.

## 2. Model
1. Create the Calendar table using the DAX in `powerbi/DAX_Measures.txt`.
2. Mark Calendar as date table.
3. Relationship: Calendar[Date] (one) -> upi_transactions[Transaction_Date] (many).
4. Add the measures from DAX_Measures.txt.

## 3. Suggested one-page report layout
Top KPI cards:
- Total Transactions
- Success Rate
- Total Transaction Value
- Successful Transaction Value
- Unique Customers

Visuals:
- Line chart: Calendar[Year-Month] vs Total Transactions; add Transaction Value as second line if desired.
- Clustered bar: UPI_App vs Total Transactions and Success Rate.
- Donut: Transaction_Status by Total Transactions.
- Bar chart: Merchant_Category vs Total Transaction Value.
- Map or bar: City vs Total Transaction Value.
- Column chart: Sender_Bank vs Total Transactions.
- Slicers: Calendar[Year], Calendar[Month], City, UPI_App, Transaction_Status.

## 4. Design
Use a clean light background, dark navy headings, and one accent color. Keep slicers in a left panel, KPI cards across the top, trend in the middle, and breakdown charts below. Format currency as ₹ with suitable display units.

## 5. Insight prompts
- Which app has the highest transaction volume?
- Which cities contribute the most transaction value?
- What is the overall success/failure rate?
- Which merchant categories have high average ticket size?
- Which hours show peak activity?
