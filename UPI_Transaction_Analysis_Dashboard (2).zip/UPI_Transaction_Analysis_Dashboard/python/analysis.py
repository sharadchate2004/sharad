"""UPI transaction analysis using pandas. Run from project root: python python/analysis.py"""
import pandas as pd
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / "data" / "upi_transactions.csv"
OUT = Path(__file__).resolve().parents[1] / "data" / "analysis_outputs"
OUT.mkdir(exist_ok=True)
df = pd.read_csv(DATA, parse_dates=["Transaction_Date"])

print("\\n--- DATA OVERVIEW ---")
print("Rows:", len(df), "| Columns:", len(df.columns))
print("Total transaction value:", round(df["Transaction_Amount"].sum(), 2))
print("Successful transactions:", (df["Transaction_Status"] == "Success").sum())

# Core KPIs
success = df[df["Transaction_Status"] == "Success"]
kpis = pd.DataFrame([{
    "Total Transactions": len(df),
    "Successful Transactions": len(success),
    "Success Rate %": round(len(success)/len(df)*100, 2),
    "Total UPI Value": round(df["Transaction_Amount"].sum(), 2),
    "Successful UPI Value": round(success["Transaction_Amount"].sum(), 2),
    "Average Transaction": round(df["Transaction_Amount"].mean(), 2),
    "Unique Customers": df["Customer_ID"].nunique()
}])
kpis.to_csv(OUT/"kpi_summary.csv", index=False)

monthly = df.assign(Month=df["Transaction_Date"].dt.to_period("M").astype(str)).groupby("Month").agg(
    Transactions=("Transaction_ID","count"),
    Transaction_Value=("Transaction_Amount","sum"),
    Successful=("Transaction_Status",lambda s:(s=="Success").sum())
).reset_index()
monthly.to_csv(OUT/"monthly_trend.csv",index=False)

by_app = df.groupby("UPI_App").agg(
    Transactions=("Transaction_ID","count"),
    Total_Value=("Transaction_Amount","sum"),
    Success_Rate=("Transaction_Status",lambda s:(s=="Success").mean()*100)
).sort_values("Total_Value",ascending=False).reset_index()
by_app.to_csv(OUT/"app_performance.csv",index=False)

by_city = df.groupby("City").agg(
    Transactions=("Transaction_ID","count"),
    Total_Value=("Transaction_Amount","sum"),
    Success_Rate=("Transaction_Status",lambda s:(s=="Success").mean()*100)
).sort_values("Total_Value",ascending=False).reset_index()
by_city.to_csv(OUT/"city_performance.csv",index=False)

by_category = df.groupby("Merchant_Category").agg(
    Transactions=("Transaction_ID","count"),
    Total_Value=("Transaction_Amount","sum")
).sort_values("Total_Value",ascending=False).reset_index()
by_category.to_csv(OUT/"merchant_category.csv",index=False)

print("\\n--- KPI SUMMARY ---")
print(kpis.to_string(index=False))
print("\\nSaved outputs to:", OUT)
